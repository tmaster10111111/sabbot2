[![Discord Bots](https://discordbots.org/api/widget/235148962103951360.svg)](https://discordbots.org/bot/235148962103951360)
[![Discord Bots](https://discordbotlist.com/bots/235148962103951360/widget)](https://discordbotlist.com/bots/235148962103951360)



[Click me to invite Carl-bot to your server](https://discordapp.com/oauth2/authorize?client_id=235148962103951360&scope=bot&permissions=470150352)

For help and questions -> [Join the bot support server](https://discord.gg/DSg744v)

<a href="https://www.patreon.com/bePatron?u=11251319"><img alt="become a patron" src="https://c5.patreon.com/external/logo/become_a_patron_button.png" height="35px"></a>

# Dashboard

Configure the bot with an easy to use interface at [https://carl.gg](https://carl.gg)

# Commands

For an explanation of the commands, please see the wiki at [https://docs.carl.gg/](https://docs.carl.gg/)

# Self hosting

Please don't. At least not now! The code is massively outdated and shares very little semblence with the live bot. This will most likely change in the future, but until then, please invite the version that I host.
